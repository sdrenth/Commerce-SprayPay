<?php
require_once strtr(realpath(dirname(dirname(__FILE__))), '\\', '/') . '/comspraypaychargeback.class.php';
/**
 * SprayPay for Commerce.
 *
 * Copyright 2018 by Your Name <your@email.com>
 *
 * This file is meant to be used with Commerce by modmore. A valid Commerce license is required.
 *
 * @package commerce_spraypay
 * @license See core/components/commerce_spraypay/docs/license.txt
 */
class comSprayPayChargeback_mysql extends comSprayPayChargeback
{

}
