Spraypay for Commerce
------------------------

A short description of what Spraypay does or how to set it up.

